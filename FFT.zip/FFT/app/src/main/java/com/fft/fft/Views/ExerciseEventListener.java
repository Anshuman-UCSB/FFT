package com.fft.fft.Views;

import com.fft.fft.workouts.Exercise;

public interface ExerciseEventListener {
    void exerciseUpdated(Exercise exercise);
}
