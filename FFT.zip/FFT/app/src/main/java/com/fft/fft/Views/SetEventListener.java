package com.fft.fft.Views;

public interface SetEventListener {
    void onCheckboxClicked(boolean checked, int index);
}
